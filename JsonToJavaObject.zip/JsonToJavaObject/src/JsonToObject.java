import java.io.IOException;

public class JsonToObject {

    final static String KEY = "prj_test_sk_c709485e4e63710dca4871b8260d1ddb662725a7";

    public static Boolean inProx(String x) {
        return x.contains("user.entered_geofence");
}

    public static void main(String[] a) throws IOException {

        String urlString = "https://api.radar.io/v1/events?limit=1";
        String response = HttpRequest
                .get(urlString)
                .header("Authorization", KEY)
                .body();
        System.out.print(inProx(response));
    }
}