public class Event {

    private String _id;
    private String createdAt;
    private String live;
    private String type;

    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("\n_id: ").append(_id);
        sb.append("\ncreatedAt: ").append(createdAt);
        sb.append("\nlive: ").append(live);
        sb.append("\ntype: ").append(type);
        return sb.toString();
    }

    public String get_id() {
        return _id;
    }
    public void set_id(String _id) {
        this._id = _id;
    }
    public String getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
    public String getLive() {
        return live;
    }
    public void setLive(String live) {
        this.live = live;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }

}